#include <iostream>
#include "persona.h"
using namespace std;

int main(){

    //ASIGNACION DE MEMORIA DINAMICA, CREAR 10 ARREGLOS
    Persona* personas = new Persona[10];
    personas[0] = Persona("Renato", 19);
    personas[1]=Persona{"Rocio", 15};
    personas[2]=Persona{"Bianca", 25};
    personas[3]=Persona{"Domenika", 30};
    personas[4]=Persona{"Alexa", 78};
    personas[5]=Persona{"Figo", 10};
    personas[6]=Persona{"Gabriel", 43};
    personas[7]=Persona{"Pablo", 60};
    personas[8]=Persona{"Juan", 24};
    personas[9]=Persona{"Alberto", 29};


    //PUNTERO PARA IMPRIMIR ARREGLO Y FUNCION QUE IMPRIME 
    Persona* ptr = personas + 9; 
    for(int i = 9; i >= 0; i--) {
        ptr->display();
        ptr--;
    }

    cout <<" " << endl;
    cout <<" " << endl;
    cout <<" " << endl;
    cout <<" " << endl;
    cout <<" " << endl;


    //PUNTERO IMPRIMA INDICES IMPAR
    cout << "ELEMENTOS CON INDICE IMPAR"<< endl;
    Persona* ptr2 = personas;
        for (int i = 1; i < 10; i += 2) {
            ptr2 = personas + i;  
            ptr2->display();     
        }


    //ELEMNTOS DEL ARREGLO TOMANDO CRITERIO DE LA EDAD
  

    //LIBREACION DE MEMORIA
    delete[] personas;
 
    return 0;
}